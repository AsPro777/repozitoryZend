-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июн 07 2023 г., 12:46
-- Версия сервера: 8.0.33
-- Версия PHP: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `zf2users`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`) VALUES
(1, 'Иван'),
(2, 'Петр'),
(3, 'Александр'),
(4, 'Виктор'),
(5, 'Михаил');

-- --------------------------------------------------------

--
-- Структура таблицы `userscity`
--

CREATE TABLE `userscity` (
  `id_user` int NOT NULL,
  `cityTitle` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `userscity`
--

INSERT INTO `userscity` (`id_user`, `cityTitle`) VALUES
(1, 'Москва'),
(2, 'Воронеж'),
(2, 'Казань'),
(3, 'Москва'),
(4, 'Воронеж'),
(4, 'Тула'),
(5, 'Казань');

-- --------------------------------------------------------

--
-- Структура таблицы `userseducations`
--

CREATE TABLE `userseducations` (
  `id_user` int NOT NULL,
  `title` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `userseducations`
--

INSERT INTO `userseducations` (`id_user`, `title`) VALUES
(1, 'школа'),
(2, 'бакалавр'),
(3, 'школа'),
(4, 'магистр'),
(5, 'высшее');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `userscity`
--
ALTER TABLE `userscity`
  ADD PRIMARY KEY (`id_user`,`cityTitle`);

--
-- Индексы таблицы `userseducations`
--
ALTER TABLE `userseducations`
  ADD PRIMARY KEY (`id_user`);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `userscity`
--
ALTER TABLE `userscity`
  ADD CONSTRAINT `userscity_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `userseducations`
--
ALTER TABLE `userseducations`
  ADD CONSTRAINT `userseducations_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
